# num-cpu

A simple Rust crate to get the number of CPU cores available to the current process.

## Usage

Add this to your `Cargo.toml`:

